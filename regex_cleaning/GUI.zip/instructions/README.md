# Regex cleaning
(Barebone done) Create a GUI to parse from csv transcription and clean up transcript (um ah space in bracket etc.)

To run, download `GUI.zip` and extract all. After that, go to `dist` then  `first_gui` and run  `first_gui.exe`

Reminder to Cat:

Convert .ipynb to .py `DIR/jupyter nbconvert --to script filename.ipynb`

Build .exe from .py `pyinstaller --onefile -w filename.py`
