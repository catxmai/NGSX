# Regex cleaning
(Barebone done) Create a GUI to parse from csv transcription and clean up transcript. 

This only supports Windows 10 for the moment. I'm trying to build it from a MacOS virtual machine. Stay tuned.

To run, download `GUI.zip` and extract all. After that, go to `dist` then  `first_gui` and run  `first_gui.exe`. Might flag as dangerous app, go to `instructions` for more help.

